package globals;

public enum AttackerEnum {
		NO_ATTACKER,		// attacker no very good no bad person
    	BAD_POSITIONS, 		// Sybile Attack
    	BAD_SIGNATURES, 	//	bad signature
    	BAD_CERTIFICATE,	// certificate
    	BAD_TIMESTAMPS,		// (replay attack)
    	BEACON_DOS,			//DOS Attack
}
